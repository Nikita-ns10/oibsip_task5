package project;

import java.util.*;

class DigitalLibraryManagement {
    // HashMaps to store data
    private HashMap<String, Integer> loginto = new HashMap<>();
    private HashMap<Integer, String> bookDatabase = new HashMap<>();
    
    // Scanner for user input
    private Scanner sc = new Scanner(System.in);
    
    // Static variables
    private static String userID;
    private static int issues = 0;
    
    // Initialize the library with books
    public HashMap<Integer, String> initializeLibrary() {
        bookDatabase.put(1, "EE : Electric Machine-1");
        bookDatabase.put(2, "EE : Electric Machine-2");
        // Add more books as needed
        
        return bookDatabase;
    }
    
    // Main method to start the program
    public static void main(String[] args) {
        DigitalLibraryManagement library = new DigitalLibraryManagement();
        library.homepage();
    }
    
    // Homepage method to display initial options
    public void homepage() {
        System.out.println("WELCOME TO DIGITAL LIBRARY MANAGEMENT SYSTEM");
        System.out.println("----------------------- HOMEPAGE -----------------------");
        System.out.println("Please Select One Option...\n");
        System.out.println("1. Admin Login");
        System.out.println("2. User Login");
        System.out.println("3. Exit");
        System.out.print("Select Option: ");
        
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                adminLogin();
                break;
            case 2:
                userLogin();
                break;
            case 3:
                System.out.println("Exiting...");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid Option Choice. Please Try Again...");
                homepage();
                break;
        }
    }
    
    // Admin login method
    public void adminLogin() {
        System.out.println("------------------- ADMIN LOGIN PAGE -------------------");
        System.out.print("Enter User-ID: ");
        userID = sc.next();
        System.out.print("Enter Password: ");
        String password = sc.next();  // Use String for password to store securely
        
        // Validate admin credentials
        if (validateAdmin(userID, password)) {
            System.out.println("\nLOGIN SUCCESSFUL!");
            adminMainPage();
        } else {
            System.out.println("\nInvalid login credentials. Please try again...");
            adminLogin();
        }
    }
    
    // Validate admin credentials (dummy method, replace with actual logic)
    private boolean validateAdmin(String userID, String password) {
        // Dummy admin credentials
        if ("admin".equals(userID) && "password".equals(password)) {
            return true;
        } else {
            return false;
        }
    }
    
    // Admin main page with options
    public void adminMainPage() {
        System.out.println(" Digital Library ---> Welcome Admin " + userID + "!");
        System.out.println("------ADMIN MAINPAGE -----");
        System.out.println("Please Select One Option...\n");
        System.out.println("1. Add a New Book");
        System.out.println("2. Update an Existing Book");
        System.out.println("3. Delete an Existing Book");
        System.out.println("4. Manage Users");
        System.out.println("5. Logout");
        System.out.print("Select Option: ");
        
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                addNewBook();
                break;
            case 2:
                updateBook();
                break;
            case 3:
                deleteBook();
                break;
            case 4:
                manageUsers();
                break;
            case 5:
                System.out.println("Logging out...");
                homepage();
                break;
            default:
                System.out.println("Invalid Option Choice. Please Try Again...");
                adminMainPage();
                break;
        }
    }
    
    // Method to add a new book to the library
    public void addNewBook() {
        System.out.println(" ADD A NEW BOOK ");
        // Implementation to add a new book
        // Ensure proper validation and error handling
        // Update database accordingly
    }
    
    // Method to update an existing book in the library
    public void updateBook() {
        System.out.println(" UPDATE A BOOK DETAILS");
        // Implementation to update an existing book
        // Ensure proper validation and error handling
        // Update database accordingly
    }
    
    // Method to delete an existing book from the library
    public void deleteBook() {
        System.out.println("DELETE A BOOK DETAILS");
        // Implementation to delete an existing book
        // Ensure proper validation and error handling
        // Update database accordingly
    }
    
    // Method to manage users (add, modify, delete)
    public void manageUsers() {
        System.out.println(" MANAGE USERS");
        // Implementation to manage users (add, modify, delete)
        // Ensure proper validation and error handling
        // Update database accordingly
    }
    
    // User login method
    public void userLogin() {
        System.out.println("------- USER LOGIN PAGE ------");
        System.out.print("Enter User-ID: ");
        userID = sc.next();
        System.out.print("Enter Password: ");
        String password = sc.next();  // Use String for password to store securely
        
        // Validate user credentials
        if (validateUser(userID, password)) {
            System.out.println("\nLOGIN SUCCESSFUL!");
            userMainPage();
        } else {
            System.out.println("\nInvalid login credentials. Please try again...");
            userLogin();
        }
    }
    
    // Validate user credentials (dummy method, replace with actual logic)
    private boolean validateUser(String userID, String password) {
        // Dummy user credentials
        if ("user".equals(userID) && "password".equals(password)) {
            return true;
        } else {
            return false;
        }
    }
    
    // User main page with options
    public void userMainPage() {
        System.out.println("----- Digital Library ---> Welcome User " + userID + "! -----");
        System.out.println("------- USER MAINPAGE ------");
        System.out.println("Please Select One Option...\n");
        System.out.println("1. View Available Books");
        System.out.println("2. Search for a Book");
        System.out.println("3. Issue a Book");
        System.out.println("4. Return a Book");
        System.out.println("5. Contact Support");
        System.out.println("6. Logout");
        System.out.print("Select Option: ");
        
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                viewAvailableBooks();
                break;
            case 2:
                searchBook();
                break;
            case 3:
                issueBook();
                break;
            case 4:
                returnBook();
                break;
            case 5:
                contactSupport();
                break;
            case 6:
                System.out.println("Logging out...");
                homepage();
                break;
            default:
                System.out.println("Invalid Option Choice. Please Try Again...");
                userMainPage();
                break;
        }
    }
    
    // Method to view available books in the library
    public void viewAvailableBooks() {
        System.out.println(" VIEW AVAILABLE BOOKS");
        // Implementation to view available books
        // Display books from database
    }
    
    // Method to search for a book by title or category
    public void searchBook() {
        System.out.println("SEARCH FOR A BOOK");
        // Implementation to search for a book
        // Allow searching by title, author, category, etc.
    }
    
    // Method to issue a book to a user
    public void issueBook() {
        System.out.println(" ISSUE A BOOK");
        // Implementation to issue a book
        // Handle user input, update database, manage issues count, etc.
    }
    
    // Method to return a book by a user
    public void returnBook() {
        System.out.println("RETURN A BOOK");
        // Implementation to return a book
        // Handle user input, update database, calculate fines if applicable, etc.
    }
    
    // Method for users to contact support via email
    public void contactSupport() {
        System.out.println("CONTACT SUPPORT ");
        // Implementation for users to contact support via email
        // Handle user input, send email, etc.
    }
}
